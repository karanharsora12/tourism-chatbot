import { Mic, Send } from 'lucide-react';
import { useState } from 'react';
import './ChatInput.css';

export default function ChatInput({ onSendMessage }) {
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (message.trim()) {
      onSendMessage(message);
      setMessage('');
    }
  };

  return (
    <div className="input-container">
      <form className="input-form" onSubmit={handleSubmit}>
        <input 
          type="text" 
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Message Gujarat AI..." 
          className="chat-input"
        />
        <button 
          type={message.trim() ? "submit" : "button"} 
          className={`action-btn ${message.trim() ? 'send-btn' : 'mic-btn'}`}
          aria-label={message.trim() ? "Send Message" : "Use Microphone"}
        >
          {message.trim() ? <Send size={18} /> : <Mic size={18} />}
        </button>
      </form>
    </div>
  );
}
