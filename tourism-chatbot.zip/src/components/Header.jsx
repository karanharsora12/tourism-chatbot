import { Home, Settings, Copy, Share2, Clock, Maximize, Trash2 } from 'lucide-react';
import './Header.css';

export default function Header() {
  return (
    <header className="chat-header">
      <div className="header-left">
        <button className="icon-btn" aria-label="Home">
          <Home size={18} />
        </button>
        <div className="brand">
          <h1>Gujarat Tourism <span className="ai-badge">AI</span></h1>
          <div className="status">
            <span className="dot"></span> Online • Travel Assistant
          </div>
        </div>
      </div>

      <div className="header-right">
        <button className="action-btn prefs-btn">
          <Settings size={14} /> Prefs
          <span className="prefs-detail">2 pax • mid-range</span>
        </button>
        <div className="ref-badge">Ref #GT2026-894729</div>
        <div className="icon-group">
          <button className="icon-btn" aria-label="Copy">
            <Copy size={18} />
          </button>
          <button className="icon-btn" aria-label="Share">
            <Share2 size={18} />
          </button>
          <button className="icon-btn" aria-label="History">
            <Clock size={18} />
          </button>
          <button className="icon-btn" aria-label="Fullscreen">
            <Maximize size={18} />
          </button>
          <button className="icon-btn delete-btn" aria-label="Delete Trip">
            <Trash2 size={18} />
          </button>
        </div>
      </div>
    </header>
  );
}
