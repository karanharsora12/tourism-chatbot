import React from 'react';
import './ChatMessage.css';
import { User } from 'lucide-react';

export default function ChatMessage({ message }) {
  const isUser = message.sender === 'user';
  
  if (isUser) {
    return (
      <div className="message-wrapper user-wrapper">
        <div className="message-content user-message">
          {message.text}
        </div>
      </div>
    );
  }

  // AI Message Rendering
  return (
    <div className="message-wrapper ai-wrapper">
      <div className="ai-header">
        <div className="ai-icon">
          <span className="dot" style={{ width: '24px', height: '24px', backgroundColor: '#00875A' }}></span>
        </div>
        <div className="ai-title-card">
          <h4>{message.title || 'Gujarat Tourism Assistant'}</h4>
          <span className="msg-time">{message.time || '12:22'}</span>
        </div>
      </div>
      
      <div className="message-content ai-message">
        {/* Render simple text, but in a real app this would parse Markdown */}
        {message.title && (
          <h3 className="ai-msg-headline">{message.headline}</h3>
        )}
        
        {message.intro && (
          <p className="ai-msg-intro">{message.intro}</p>
        )}

        {message.days && message.days.map((day, idx) => (
          <div key={idx} className="day-block">
            <h5 className="day-title">{day.title}</h5>
            <ul className="day-activities">
              {day.activities.map((act, i) => (
                <li key={i}>
                  <strong>{act.type}:</strong> {act.description}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
