import { ChevronRight } from 'lucide-react';
import './PreferencesBanner.css';

export default function PreferencesBanner() {
  return (
    <div className="banner-container">
      <div className="banner-content">
        <div className="banner-left">
          <span className="banner-icon">✨</span>
          <span className="banner-text">Set your travel preferences</span>
          <ChevronRight size={16} className="chevron" />
        </div>
        <button className="quick-set-btn">Quick Setup</button>
      </div>
    </div>
  );
}
